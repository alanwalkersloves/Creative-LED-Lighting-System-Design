	#include <REGX51.H>//ͷ�ļ�
	#include "intrins.h"

	#define uchar unsigned char//������������
	#define uint unsigned int

	#define LED_WHITE 	P1	//ʹ�ú궨��P1�˿�
	#define LED_PORT 	  P2	//ʹ�ú궨��P2�˿�
	#define LED_GREEN 	P0	//ʹ�ú궨��P0�˿�

	sbit LSA=P3^0;//λ����
	sbit LSB=P3^1;
	sbit LSC=P3^4;
	uchar dutyCycle = 0; // 50%???
	uint n=100;
void Delay_us(unsigned int xus) // ???????
{
    while(xus--);
}

	void Delay_ms(unsigned int xms)//��ʱ����
	{
		unsigned char i, j;
		while(xms--)
		{
			i = 2;
			j = 239;
			do
			{
				while (--j);
			} while (--i);
		}
	}
void generatePWM(dutyCycle,  LED) {
    unsigned int i;
    for (i = 0; i < 255; i++) {
        if (i < dutyCycle) {
            LED = 0; // ???
        } else {
            LED = 1; // ???
        }
        Delay_ms(1);
    }
		
		
	}

	void IntInit()//��ʼ���ⲿ�ж�1
	{
		IT1 = 1;	
		EX1 = 1;
		IT0 = 1;	
		EX0 = 1;
		EA = 1;		
	}

	void main()
	{
		uchar i=0,k=0,t=0,m=0;
		IntInit();
		LED_WHITE=0xfe;
		LED_GREEN=0xfe;
		LED_PORT =0xfe;
		while(1)
		{
			for(i=0;i<8;i++)	 
			{									  
				LED_WHITE=_crol_(LED_WHITE,1);
				generatePWM(dutyCycle, P1^i);
					
			}
			for(k=0;k<8;k++)	 
			{									  
				LED_GREEN=_crol_(LED_GREEN,1);
				generatePWM(dutyCycle, P0^k);  
				 	
			}
			LSB=0;
			LSA=0;
			for(t=0;t<8;t++)	 
			{	
				LSB=1;			
				LED_PORT=_crol_(LED_PORT,1);
				generatePWM(dutyCycle, P2^t);   
				
				LSB=0;			
			}
			LSC=0;
			LSA=0;
			for(m=0;m<8;m++)	 
			{	
				LSC=1;			
				LED_PORT=_crol_(LED_PORT,1);
				generatePWM(dutyCycle, P2^m);   
				
				LSC=0;			
			}
			for(i=0;i<8;i++)	 
			{									  
				LED_WHITE=_crol_(LED_WHITE,2);
				generatePWM(dutyCycle, P1^i);
				LED_GREEN=_crol_(LED_GREEN,2);
				generatePWM(dutyCycle, P0^i);  
				 	
			}
			for(i=0;i<8;i++)	 
			{									  
				LED_WHITE=_cror_(LED_WHITE,1);
				generatePWM(dutyCycle, P1^i);
					
			}
			for(k=0;k<8;k++)	 
			{									  
				LED_GREEN=_cror_(LED_GREEN,1);
				generatePWM(dutyCycle, P0^i);  
				
			}
			for(i=0;i<8;i++)	 
			{									  
				LED_WHITE=_crol_(LED_WHITE,4);
				generatePWM(dutyCycle, P1^i);
				LED_GREEN=_crol_(LED_GREEN,4);
				 	
			}
			LSB=0;
			LSA=0;
			for(t=0;t<8;t++)	 
			{	
				LSB=1;			
				LED_PORT=_cror_(LED_PORT,1);
				generatePWM(dutyCycle, P2^t);   
				
				LSB=0;			
			}
			LSC=0;
			LSA=0;
			for(m=0;m<8;m++)
			{	
				LSC=1;			
				LED_PORT=_cror_(LED_PORT,1);
				generatePWM(dutyCycle, P2^m);   
				
				LSC=0;			
			}
			LSB=0;
			LSA=0;
			for(t=0;t<8;t++)	 
			{	
				LSB=1;			
				LED_PORT=_cror_(LED_PORT,2);
				generatePWM(dutyCycle, P2^t);   
				
				LSB=0;			
			}
			LSC=0;
			LSA=0;
			for(m=0;m<8;m++)	 
			{	
				LSC=1;			
				LED_PORT=_cror_(LED_PORT,2);
				generatePWM(dutyCycle, P2^m);   
				
				LSC=0;			
			}
		}
	}

	void Int0()	   interrupt 0
	{	
		 dutyCycle += 32; 

	}
	
	void Int1()	   interrupt 2
	{	
		n=n+100;
		if (n>5)
			n=100;
	}
#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit PAB=P3^0;
sbit PA=P3^1;
sbit PB=P3^4;

uchar code table[]={0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};
uchar i;
float k=0.75;
float m;

float n=180;
float H=240;

qingling()
{PAB=0;
PA=0;
PB=0;
return PAB,PA,PB;}

panduan(y)
{if(y>23)
{y=y-24;
if(y>15)
{y=y-16;
if(y>7)
{y=y-8;}
}
}
return y;
}


void delay_ms(unsigned int xms)//��ʱ����
	{
		unsigned char i, j;
		while(xms--)
		{
			i = 2;
			j = 400;
			do
			{
				while (--j);
			} while (--i);
		}
	}


main(){
IT0=IT1=1;
EA=EX0=EX1=1;
m=H-n;
while(1)
{

for(i=0;i<8;i++)	
{
P1=table[i];delay_ms(n);
P1=0xff; delay_ms(m);
}

for(i=0;i<8;i++)	
{
P0=table[i];delay_ms(n);
P0=0xff;delay_ms(m);

}


qingling();
for(i=0;i<8;i++)	
{
PA=1;
P2=table[i];delay_ms(n);
P2=0xff;delay_ms(m);
PA=0;

}

qingling();
for(i=0;i<8;i++)	
{
PB=1;
P2=table[i];delay_ms(n);
P2=0xff;delay_ms(m);
PB=0;
}

qingling();

for(i=0;i<8;i++)	
{uchar y=2*i;
if(y>7)
{y=y-8;}

P1=table[y];
P0=table[y];
delay_ms(n);
P1=P0=0xff;
delay_ms(m);

}

for(i=7;i>0;i--)
{
P1=table[i];delay_ms(n);
P1=0xff;delay_ms(m);
}

for(i=7;i>0;i--)
{
P0=table[i];delay_ms(n);
P0=0xff;delay_ms(m);
}

for(i=0;i<8;i++)	
{uchar y=4*i;
y=panduan(y);

P1=table[y];
P0=table[y];
	delay_ms(n);
P1=P0=0xff;
	delay_ms(m);
	
}

qingling();
for(i=7;i>0;i--)	
{
PA=1;
P2=table[i];delay_ms(n);
P2=0xff;delay_ms(m);
PA=0;
}
qingling();

for(i=7;i>0;i--)	
{
PB=1;
P2=table[i];delay_ms(n);
P2=0xff;delay_ms(m);
PB=0;
}
qingling();

for(i=7;i>0;i--)	
{uchar y=2*i;
y=panduan(y);
PA=1;
P2=table[y];delay_ms(n);
P2=0xff;delay_ms(m);
PA=0;
}
qingling();

for(i=7;i>0;i--)	
{uchar y=2*i;
y=panduan(y);

PB=1;
P2=table[y];delay_ms(n);
P2=0xff;delay_ms(m);
PB=0;
}
qingling();


}
}

it0() interrupt 0
{n=H*(k-0.35);
	m=H-n+40;
 if(n<0)
 {n=H*k;
	m=H*k;}
}
in2() interrupt 2
{H+=300;
	if(H>1000)
		H=256;
}